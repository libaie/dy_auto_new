// device/core/ai-analyzer.js
var config = global.__config || require("../config");
var logger = require("../utils/logger");

var TAG = "AI";

/**
 * 设备端 AI 分析模块
 * 五维度打分模型：意图识别 + 情感倾向 + 关注实体 + 用户画像 + 线索质量
 */
var aiAnalyzer = {
  // 阈值：达到此分数才触发回复
  SCORE_THRESHOLD: 60,

  /**
   * 分析单条评论
   * @param {Object} params
   *   - searchKeyword: string (搜索关键词)
   *   - nickname: string (评论者昵称)
   *   - commentText: string (评论内容)
   * @returns {Object|null} { score, tier, dimensions, reply }
   */
  analyzeComment: function (params) {
    var searchKeyword = params.searchKeyword;
    var nickname = params.nickname;
    var commentText = params.commentText;

    if (!commentText) {
      logger.warn(TAG, "Empty comment text");
      return null;
    }

    // 调用 AI 进行五维度分析 + 生成回复
    var result = this._analyzeAndReply(searchKeyword, nickname, commentText);
    if (!result) {
      logger.warn(TAG, "AI analysis failed");
      return null;
    }

    return result;
  },

  /**
   * 调用 AI 进行五维度分析并生成回复
   * @param {string} searchKeyword
   * @param {string} nickname
   * @param {string} commentText
   * @returns {Object|null} { score, tier, dimensions, reply }
   */
  _analyzeAndReply: function (searchKeyword, nickname, commentText) {
    var aiConfig = config.ai;
    if (!aiConfig.apiKey) {
      logger.error(TAG, "AI API key not configured");
      return null;
    }

    var prompt = this._buildAnalysisPrompt(searchKeyword, nickname, commentText);

    try {
      var response = http.post(aiConfig.apiUrl, {
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + aiConfig.apiKey,
        },
        body: JSON.stringify({
          model: aiConfig.model,
          max_tokens: 512,
          temperature: 0.3, // 低温度保证分析稳定性
          messages: [
            { role: "user", content: prompt },
          ],
        }),
        timeout: 30000,
      });

      if (response.statusCode !== 200) {
        logger.error(TAG, "AI API error: " + response.statusCode + " - " + response.body);
        return null;
      }

      var result = JSON.parse(response.body);
      var content = result.choices[0].message.content.trim();

      // 解析 JSON 响应
      return this._parseAnalysisResponse(content);
    } catch (e) {
      logger.error(TAG, "AI API call failed: " + e.message);
      return null;
    }
  },

  /**
   * 解析 AI 分析响应
   * @param {string} content - AI 返回的 JSON 字符串
   * @returns {Object|null}
   */
  _parseAnalysisResponse: function (content) {
    try {
      // 提取 JSON（AI 可能会添加额外文本）
      var jsonMatch = content.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        logger.error(TAG, "No JSON found in AI response");
        return null;
      }

      var data = JSON.parse(jsonMatch[0]);

      // 验证必要字段
      if (typeof data.score !== "number" || !data.reply) {
        logger.error(TAG, "Invalid AI response structure");
        return null;
      }

      // 清理回复（去掉引号等）
      data.reply = data.reply.replace(/^["'「]|["'」]$/g, "");

      return data;
    } catch (e) {
      logger.error(TAG, "Parse AI response failed: " + e.message);
      return null;
    }
  },

  /**
   * 检查当前内容是否与大健康领域相关
   * @param {string} contentText - 从屏幕提取的文本（标题、描述、标签等）
   * @param {string} [domain] - 目标领域描述，默认 "大健康"
   * @returns {boolean} true=相关，false=不相关或判断失败
   */
  checkHealthRelevance: function (contentText, domain) {
    if (!contentText || contentText.length < 2) return true; // 文本太少时默认放行

    var aiConfig = config.ai;
    if (!aiConfig.apiKey) {
      logger.warn(TAG, "AI未配置，默认放行");
      return true;
    }

    domain = domain || "大健康（养生、保健、中医、食疗、营养、运动健身、心理健康、慢病管理、亚健康调理）";

    var prompt = "判断以下抖音视频内容是否与" + domain + "领域相关。\n\n" +
      "内容：" + contentText.substring(0, 300) + "\n\n" +
      "只回答一个JSON：{\"related\": true/false, \"reason\": \"简短原因\"}";

    try {
      var response = http.post(aiConfig.apiUrl, {
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + aiConfig.apiKey,
        },
        body: JSON.stringify({
          model: aiConfig.model,
          max_tokens: 100,
          temperature: 0.1,
          messages: [{ role: "user", content: prompt }],
        }),
        timeout: 15000,
      });

      if (response.statusCode !== 200) {
        logger.warn(TAG, "内容判断API错误: " + response.statusCode + "，默认放行");
        return true;
      }

      var result = JSON.parse(response.body);
      var content = result.choices[0].message.content.trim();
      var jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        var data = JSON.parse(jsonMatch[0]);
        logger.info(TAG, "内容相关性: " + (data.related ? "相关" : "不相关") + " - " + (data.reason || ""));
        return !!data.related;
      }
    } catch (e) {
      logger.warn(TAG, "内容判断失败: " + e.message + "，默认放行");
    }
    return true; // 判断失败时默认放行，不阻塞流程
  },

  /**
   * 根据视频内容生成评论
   * @param {string} videoText - 从屏幕提取的视频文本（标题、描述、标签等）
   * @returns {string|null} 生成的评论内容，失败返回 null
   */
  generateVideoComment: function (videoText) {
    if (!videoText || videoText.length < 2) {
      logger.warn(TAG, "视频文本太短，无法生成评论");
      return null;
    }

    var aiConfig = config.ai;
    if (!aiConfig.apiKey) {
      logger.warn(TAG, "AI 未配置，无法生成评论");
      return null;
    }

    var prompt = "你是一个抖音用户，正在浏览健康/养生类短视频。请根据视频内容写一条自然、真实的评论。\n\n" +
      "## 要求\n" +
      "- 像真人刷抖音时随手写的评论，不要太正式\n" +
      "- 15-30字，口语化\n" +
      "- 结合视频具体内容（标题、话题、描述）\n" +
      "- 可以用语气词、表情符号\n" +
      "- 严禁禁用词：治愈/根治/治好/疗效保证/替代药物/停药/医生/专家/保证有效/百分百/神药\n" +
      "- 严禁营销感：不要带链接、不要引导加微信\n" +
      "- 不要以「同感」「我也是」「确实」开头\n\n" +
      "## 视频内容\n" + videoText.substring(0, 500) + "\n\n" +
      "只输出评论文本，不要引号、不要其他解释。";

    return this._generateText(prompt, "评论");
  },

  /**
   * 根据视频内容生成私信
   * @param {string} videoText - 从屏幕提取的视频文本
   * @returns {string|null} 生成的私信内容，失败返回 null
   */
  generateVideoDM: function (videoText) {
    if (!videoText || videoText.length < 2) {
      logger.warn(TAG, "视频文本太短，无法生成私信");
      return null;
    }

    var aiConfig = config.ai;
    if (!aiConfig.apiKey) {
      logger.warn(TAG, "AI 未配置，无法生成私信");
      return null;
    }

    var prompt = "你是一个抖音用户，看到一条健康/养生相关视频后想和博主私信交流。请根据视频内容写一条友好的私信。\n\n" +
      "## 要求\n" +
      "- 像普通人私信，自然亲切\n" +
      "- 20-40字\n" +
      "- 结合视频具体内容，表明你是看了他的视频才来聊的\n" +
      "- 可以表达共鸣、请教、分享经验\n" +
      "- 严禁禁用词：治愈/根治/治好/疗效保证/替代药物/停药/医生/专家/保证有效/百分百/神药\n" +
      "- 严禁营销感：不要带链接、不要推销\n\n" +
      "## 视频内容\n" + videoText.substring(0, 500) + "\n\n" +
      "只输出私信文本，不要引号、不要其他解释。";

    return this._generateText(prompt, "私信");
  },

  /**
   * 通用文本生成
   * @param {string} prompt - 提示词
   * @param {string} tag - 日志标签
   * @returns {string|null} 生成的文本，失败返回 null
   */
  _generateText: function (prompt, tag) {
    var aiConfig = config.ai;

    try {
      var response = http.post(aiConfig.apiUrl, {
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + aiConfig.apiKey,
        },
        body: JSON.stringify({
          model: aiConfig.model,
          max_tokens: 200,
          temperature: 0.8, // 较高温度增加多样性
          messages: [{ role: "user", content: prompt }],
        }),
        timeout: 20000,
      });

      if (response.statusCode !== 200) {
        logger.error(TAG, tag + " AI API error: " + response.statusCode);
        return null;
      }

      var result = JSON.parse(response.body);
      var text = result.choices[0].message.content.trim();
      // 去掉可能的引号包裹
      text = text.replace(/^["'「]|["'」]$/g, "");
      logger.info(TAG, "AI 生成" + tag + ": '" + text.substring(0, 30) + "'");
      return text;
    } catch (e) {
      logger.error(TAG, "AI 生成" + tag + "失败: " + e.message);
      return null;
    }
  },

  /**
   * 构建五维度分析提示词
   */
  _buildAnalysisPrompt: function (searchKeyword, nickname, commentText) {
    return '你是一个抖音评论分析专家，需要对评论进行五维度分析并生成回复。\n\n' +
      '## 任务\n' +
      '分析以下评论，输出 JSON 格式的分析结果和回复。\n\n' +
      '## 五维度分析模型\n\n' +
      '### 1. 意图识别 (intent) - 核心转化指标\n' +
      '判断用户发这条评论的真实目的：\n' +
      '- buy_intent (求购/交易意图): 高价值线索。"怎么买？"、"多少钱？"、"求链接"、"小黄车里没有啊"\n' +
      '- consult_intent (求知/咨询意图): 潜在线索。"这个怎么用？"、"敏感肌可以用吗？"\n' +
      '- compare_intent (对比/摇摆意图): 极佳切入点。"这个和XX比哪个好？"、"有没有平替？"\n' +
      '- meaningless (无意义/闲聊): 需过滤。"哈哈哈"、"第一"、"打卡"或纯表情\n\n' +
      '### 2. 情感倾向 (sentiment) - 切入策略指标\n' +
      '- positive (正向): 赞赏、喜欢、期待\n' +
      '- negative (负向): 抱怨、吐槽、踩坑 - 极具截流价值的痛点\n' +
      '- neutral (中立): 客观陈述、疑问\n\n' +
      '### 3. 关注实体 (focus) - 产品痛点指标\n' +
      '- price (价格敏感): "贵"、"便宜"、"折扣"、"运费"\n' +
      '- quality (质量/功能): "材质"、"续航"、"掉色"、"售后"\n' +
      '- location (地域/本地): 具体城市、商圈\n' +
      '- other (其他)\n\n' +
      '### 4. 用户画像 (profile) - 客户资质指标\n' +
      '- role (社会角色): 宝妈、学生、职场人等\n' +
      '- spending (消费能力): low/mid/high\n\n' +
      '### 5. 线索质量 (lead_quality) - 清洗与排序\n' +
      '- urgency (紧急度): 1-10分\n' +
      '- is_bot (是否水军/机器人): true/false\n' +
      '- is_competitor (是否同行): true/false\n\n' +
      '## 评分规则\n' +
      '总分 = intent分 + sentiment分 + focus分 + profile分 + urgency分\n' +
      '- buy_intent: 50分\n' +
      '- compare_intent: 40分\n' +
      '- consult_intent: 30分\n' +
      '- meaningless: 0分\n' +
      '- negative情感: +20分\n' +
      '- positive情感: +10分\n' +
      '- price敏感: +10分\n' +
      '- urgency > 7: +10分\n' +
      '- is_bot/is_competitor: 直接0分\n\n' +
      '## 回复生成规则\n' +
      '- 搜索词是健康/养生领域时，使用健康科普风格\n' +
      '- 严禁禁用词：治愈/根治/治好/疗效保证/替代药物/停药/医生/专家/保证有效/百分百/神药\n' +
      '- 不做诊断，不保证疗效，讨论日常饮食生活习惯\n' +
      '- 严禁自我代入：不要用"我都是…"、"我自己…"\n' +
      '- 使用建议风格："可以试试"、"建议"、"若想…"\n' +
      '- 单条不超过30字，严禁以"同感"、"我也是"、"确实"开头\n' +
      '- 根据意图和情感调整话术：\n' +
      '  - buy_intent: 可分享使用经验或提出建议角度\n' +
      '  - consult_intent: 从饮食/运动/习惯角度切入\n' +
      '  - negative: 理解痛点，提供替代方案\n' +
      '  - compare_intent: 客观对比，突出优势\n\n' +
      '## 输入\n' +
      '- 搜索词：' + searchKeyword + '\n' +
      '- 对方昵称：' + nickname + '\n' +
      '- 对方的评论：' + commentText + '\n\n' +
      '## 输出格式（严格 JSON）\n' +
      '{\n' +
      '  "score": 75,\n' +
      '  "tier": "high",\n' +
      '  "dimensions": {\n' +
      '    "intent": "buy_intent",\n' +
      '    "sentiment": "positive",\n' +
      '    "focus": "price",\n' +
      '    "profile": { "role": "unknown", "spending": "mid" },\n' +
      '    "lead_quality": { "urgency": 8, "is_bot": false, "is_competitor": false }\n' +
      '  },\n' +
      '  "reply": "可以试试饭前喝点稀释的苹果水，对胃比较温和"\n' +
      '}\n\n' +
      'tier 规则：score >= 70 为 "high"，40-69 为 "medium"，< 40 为 "low"\n' +
      '请直接输出 JSON，不要其他文本。';
  },
};

module.exports = aiAnalyzer;
