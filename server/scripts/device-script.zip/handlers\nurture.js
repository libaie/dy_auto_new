// device/handlers/nurture.js
var BaseHandler = require("./base-handler");
var uiOperator = require("../core/ui-operator");
var antiDetect = require("../core/anti-detect");
var aiAnalyzer = require("../core/ai-analyzer");
var logger = require("../utils/logger");

var TAG = "养号";

/**
 * 养号 Handler
 * V2 params:
 *   - sub_tasks: Array<{ type: string, count: number, content_template_id?: string }>
 *   - completion_mode: "all" | "any"
 *   - duration: number (最大时长，分钟)
 * Legacy params:
 *   - duration: number (养号时长，分钟)
 *   - actions: Array<{ type: string, weight: number }>
 */
var NurtureHandler = Object.create(BaseHandler);

NurtureHandler.execute = function (params) {
  // V2 format: sub_tasks + completion_mode
  if (params.sub_tasks) {
    return this._executeV2(params);
  }
  // Legacy format: duration + actions
  return this._legacyExecute(params);
};

NurtureHandler._executeV2 = function (params) {
  var subTasks = params.sub_tasks;
  var completionMode = params.completion_mode || "all";
  var maxDuration = (params.duration || 60) * 60 * 1000;
  var startTime = Date.now();

  logger.info(TAG, "开始养号 V2, 子任务数=" + subTasks.length + ", 模式=" + completionMode);

  if (!this.ensureAppActive()) {
    return { success: false, error: "Failed to open Douyin" };
  }

  // Initialize progress for each sub-task
  var progress = subTasks.map(function (st) {
    return {
      type: st.type,
      target: st.count,
      done: 0,
      contentTemplateId: st.content_template_id || null,
    };
  });

  while (Date.now() - startTime < maxDuration) {
    // Find incomplete sub-tasks
    var pending = progress.filter(function (p) { return p.done < p.target; });
    if (pending.length === 0) {
      logger.info(TAG, "所有子任务已完成");
      break;
    }

    // Randomly pick one incomplete sub-task
    var task = pending[Math.floor(Math.random() * pending.length)];

    // 执行前确保在推荐页（防止误触跳转后所有操作都在错误页面）
    this._ensureOnFeed();

    try {
      this._executeSubTask(task);
      task.done++;
    } catch (e) {
      logger.error(TAG, "子任务 '" + task.type + "' 出错: " + e.message);
    }

    // Log progress
    var progressSummary = progress.map(function (p) {
      return p.type + ":" + p.done + "/" + p.target;
    }).join(" ");
    logger.info(TAG, "进度: " + progressSummary);

    // Check completion condition
    if (completionMode === "any") {
      var anyDone = progress.some(function (p) { return p.done >= p.target; });
      if (anyDone) {
        logger.info(TAG, "任一子任务完成，结束养号");
        break;
      }
    }

    antiDetect.humanSwipeUp();
  }

  // Build stats
  var stats = {};
  progress.forEach(function (p) {
    stats[p.type] = { target: p.target, done: p.done };
  });

  logger.info(TAG, "养号 V2 完成: " + JSON.stringify(stats));
  return { success: true, result: stats };
};

NurtureHandler._executeSubTask = function (task) {
  switch (task.type) {
    case "browse":
      this._browseFeed();
      break;
    case "watch":
      this._watchVideo();
      break;
    case "like":
      this._likeCurrentVideo();
      break;
    case "comment":
      this._commentOnVideo(task.contentTemplateId);
      break;
    case "follow":
      this._followCurrentUser();
      break;
    default:
      this._browseFeed();
  }
};

NurtureHandler._browseFeed = function () {
  this._ensureOnFeed();
  // 浏览推荐页：快速扫一眼，大部分 2-5 秒，偶尔多停一会
  var watchTime = this._humanDuration(2000, 8000, 4000);
  logger.debug(TAG, "浏览推荐页 " + Math.round(watchTime / 1000) + "s");
  sleep(watchTime);
};

NurtureHandler._watchVideo = function () {
  // 先检测是否是广告 — 广告快速划走
  if (this._isAdContent()) {
    var adTime = Math.floor(Math.random() * 1500 + 500);
    logger.debug(TAG, "检测到广告，快速划走 " + adTime + "ms");
    sleep(adTime);
    return;
  }

  // 检测内容互动数据来判断质量
  var quality = this._assessContentQuality();
  var watchTime;

  if (quality === "high") {
    // 精彩内容：看得久，30-60 秒，偶尔模拟看评论
    watchTime = this._humanDuration(25000, 60000, 40000);
    logger.debug(TAG, "精彩内容，深度观看 " + Math.round(watchTime / 1000) + "s");
  } else if (quality === "medium") {
    // 普通内容：15-30 秒
    watchTime = this._humanDuration(12000, 30000, 20000);
    logger.debug(TAG, "普通内容，正常观看 " + Math.round(watchTime / 1000) + "s");
  } else {
    // 无亮点内容：3-10 秒快速划走
    watchTime = this._humanDuration(3000, 10000, 5000);
    logger.debug(TAG, "无亮点内容，快速划走 " + Math.round(watchTime / 1000) + "s");
  }

  sleep(watchTime);

  // 精彩内容有概率模拟看评论区（停留更久）
  if (quality === "high" && Math.random() < 0.3) {
    var commentPause = Math.floor(Math.random() * 5000 + 3000);
    logger.debug(TAG, "模拟浏览评论区 " + Math.round(commentPause / 1000) + "s");
    sleep(commentPause);
  }
};

/**
 * 生成拟人化的观看时长 — 基于对数正态分布
 * 大部分时间偏短，偶尔有长停留，符合真实用户行为
 * @param {number} min - 最小时长(ms)
 * @param {number} max - 最大时长(ms)
 * @param {number} median - 中位数(ms)，控制主体集中位置
 * @returns {number} 拟人化的时长(ms)
 */
NurtureHandler._humanDuration = function (min, max, median) {
  // 对数正态分布：ln(N(mu, sigma)) 产生右偏分布
  var mu = Math.log(median);
  var sigma = 0.5; // 控制离散程度，0.3-0.6 较自然
  // Box-Muller 变换生成正态随机数
  var u1 = Math.random();
  var u2 = Math.random();
  var z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  var value = Math.exp(mu + sigma * z);
  // 限制在 [min, max] 范围内
  return Math.max(min, Math.min(max, Math.round(value)));
};

/**
 * 检测当前屏幕是否为广告内容
 * @returns {boolean}
 */
NurtureHandler._isAdContent = function () {
  try {
    // 常见广告标识文本
    var adTexts = ["广告", "推广", "赞助", "购物", "立即购买", "查看详情"];
    for (var i = 0; i < adTexts.length; i++) {
      var el = textContains(adTexts[i]).findOnce();
      if (el) {
        logger.debug(TAG, "发现广告标识: " + adTexts[i]);
        return true;
      }
    }
    // 检查是否在购物/商品页面（右下角有购物车图标）
    var shopBtn = desc("购物车").findOnce();
    if (shopBtn) {
      logger.debug(TAG, "发现购物车标识，判定为广告");
      return true;
    }
  } catch (e) {
    // 检测失败不影响正常流程
  }
  return false;
};

/**
 * 评估当前视频内容质量 — 基于可见的互动数据
 * @returns {"high" | "medium" | "low"}
 */
NurtureHandler._assessContentQuality = function () {
  try {
    // 尝试读取点赞数（控件 id 可能随版本变化）
    var likeCountEl = id("com.ss.android.ugc.aweme:id/like_count").findOnce();
    if (likeCountEl) {
      var likeText = likeCountEl.text() || "";
      var likeNum = this._parseCount(likeText);
      // 高赞内容判定：万级以上
      if (likeNum >= 10000) return "high";
      if (likeNum >= 1000) return "medium";
    }

    // 尝试读取评论数
    var commentCountEl = id("com.ss.android.ugc.aweme:id/comment_count").findOnce();
    if (commentCountEl) {
      var commentText = commentCountEl.text() || "";
      var commentNum = this._parseCount(commentText);
      if (commentNum >= 1000) return "high";
      if (commentNum >= 100) return "medium";
    }
  } catch (e) {
    // 读取失败时降级为随机判定
  }

  // 无法读取数据时，用概率模拟：20% 高、50% 中、30% 低
  var r = Math.random();
  if (r < 0.2) return "high";
  if (r < 0.7) return "medium";
  return "low";
};

/**
 * 解析抖音互动数字文本（支持 "1.2万"、"3.5亿" 等格式）
 * @param {string} text - 数字文本
 * @returns {number}
 */
NurtureHandler._parseCount = function (text) {
  if (!text) return 0;
  text = text.replace(/,/g, "").trim();
  if (text.indexOf("w") !== -1 || text.indexOf("万") !== -1) {
    return Math.round(parseFloat(text) * 10000);
  }
  if (text.indexOf("亿") !== -1) {
    return Math.round(parseFloat(text) * 100000000);
  }
  var num = parseInt(text, 10);
  return isNaN(num) ? 0 : num;
};

/**
 * 确保在推荐页 — 如果误触跳转到其他页面，使用 back_btn 选择器返回推荐页
 * 抖音推荐页特征：底部有"首页"tab，右侧有点赞/评论按钮
 * 支持最多重试 3 次，防止卡在某个页面出不来
 */
NurtureHandler._ensureOnFeed = function () {
  var maxRetries = 3;
  for (var attempt = 0; attempt < maxRetries; attempt++) {
    try {
      // 检测是否在推荐页 — 有点赞按钮说明在推荐视频流
      var likeBtn = id("com.ss.android.ugc.aweme:id/like_btn").findOnce();
      if (likeBtn) return; // 已在推荐页

      // 检测是否在个人主页（有"橱窗"、"作品"、"喜欢"、"关注"等标签）
      var shopTab = text("橱窗").findOnce();
      var worksTab = text("作品").findOnce();
      var likesTab = text("喜欢").findOnce();
      if (shopTab || worksTab || likesTab) {
        logger.info(TAG, "检测到在个人主页（第" + (attempt + 1) + "次），使用 back_btn 返回");
        this.safeClick("back_btn", 2);
        sleep(1500);
        continue;
      }

      // 检测是否在搜索页
      var searchPage = text("搜索").className("android.widget.EditText").findOnce();
      if (searchPage) {
        logger.info(TAG, "检测到在搜索页，使用 back_btn 返回");
        this.safeClick("back_btn", 2);
        sleep(1000);
        continue;
      }

      // 检测是否在评论区（评论输入框可见）
      var commentEt = id("com.ss.android.ugc.aweme:id/comment_et").findOnce();
      if (commentEt) {
        logger.info(TAG, "检测到在评论区，使用 back_btn 返回");
        this.safeClick("back_btn", 2);
        sleep(1000);
        continue;
      }

      // 检测是否在视频详情页（全屏视频，无底部 tab）
      var bottomTab = id("com.ss.android.ugc.aweme:id/tab_layout").findOnce();
      if (!bottomTab) {
        // 没有底部 tab，可能在视频全屏页或子页面
        logger.info(TAG, "未检测到底部 tab，尝试 back_btn 返回");
        this.safeClick("back_btn", 2);
        sleep(1000);
        continue;
      }

      // 其他未知页面，尝试返回
      logger.info(TAG, "未知页面状态，尝试 back_btn 返回（第" + (attempt + 1) + "次）");
      this.safeClick("back_btn", 2);
      sleep(1000);
    } catch (e) {
      logger.warn(TAG, "页面检测异常: " + e.message);
    }
  }
  logger.warn(TAG, maxRetries + " 次尝试后仍未回到推荐页");
};

NurtureHandler._likeCurrentVideo = function () {
  var text = this._extractVideoText();
  if (!aiAnalyzer.checkHealthRelevance(text)) {
    logger.info(TAG, "内容与大健康不相关，跳过点赞");
    return;
  }
  var clicked = this.safeClick("like_button", 2);
  if (clicked) {
    logger.info(TAG, "点赞成功");
  }
};

NurtureHandler._commentOnVideo = function (templateId) {
  // 1. 提取视频内容，AI 生成评论
  var videoText = this._extractVideoText();
  var content = aiAnalyzer.generateVideoComment(videoText);
  if (!content) {
    logger.warn(TAG, "AI 生成评论失败，跳过评论");
    return;
  }
  logger.info(TAG, "AI 生成评论: '" + content.substring(0, 20) + "'");

  // 2. 点击评论入口按钮，打开评论面板
  var opened = this.safeClick("video_comment_btn", 3);
  if (!opened) {
    logger.warn(TAG, "评论入口按钮未找到");
    return;
  }
  sleep(1500);

  // 3. 点击评论输入框，弹出键盘
  var inputClicked = this.safeClick("video_comment_input", 3);
  if (!inputClicked) {
    logger.warn(TAG, "评论输入框未找到");
    back();
    sleep(500);
    return;
  }
  sleep(1000);

  // 4. 输入评论内容
  var inputResult = this.safeInput("video_comment_input", content);
  if (!inputResult) {
    logger.warn(TAG, "输入评论内容失败");
    back();
    sleep(500);
    return;
  }
  sleep(500);

  // 5. 提交评论
  this.safeClick("comment_submit", 2);
  sleep(1000);
  logger.info(TAG, "评论成功");

  // 6. 关闭评论面板
  this.safeClick("back_btn", 2);
  sleep(800);
};

NurtureHandler._followCurrentUser = function () {
  var text = this._extractVideoText();
  if (!aiAnalyzer.checkHealthRelevance(text)) {
    logger.info(TAG, "内容与大健康不相关，跳过关注");
    return;
  }
  var clicked = this.safeClick("follow_button", 2);
  if (clicked) {
    logger.info(TAG, "关注成功");
  }
};

/**
 * 从当前屏幕提取视频相关文本（标题、描述、作者等）
 * @returns {string} 拼接的文本内容
 */
NurtureHandler._extractVideoText = function () {
  var parts = [];
  try {
    // 视频描述/标题
    var desc = id("com.ss.android.ugc.aweme:id/desc").findOnce();
    if (desc && desc.text()) parts.push(desc.text());

    // 作者昵称
    var author = id("com.ss.android.ugc.aweme:id/nickname").findOnce();
    if (author && author.text()) parts.push(author.text());

    // 话题标签
    var hashtags = className("android.widget.TextView").find();
    for (var i = 0; i < Math.min(hashtags.length, 10); i++) {
      var t = hashtags[i].text() || "";
      if (t.indexOf("#") !== -1 || t.indexOf("话题") !== -1) {
        parts.push(t);
      }
    }

    // 兜底：抓取屏幕上所有可见的短文本（标题、按钮文字等）
    if (parts.length === 0) {
      var allTexts = className("android.widget.TextView").find();
      for (var j = 0; j < Math.min(allTexts.length, 15); j++) {
        var txt = allTexts[j].text() || "";
        // 过滤掉太短的和纯数字/符号
        if (txt.length >= 3 && !/^\d+$/.test(txt) && !/^[^一-龥a-zA-Z]+$/.test(txt)) {
          parts.push(txt);
        }
      }
    }
  } catch (e) {
    logger.debug(TAG, "提取视频文本失败: " + e.message);
  }
  return parts.join(" | ");
};

// --- Legacy support ---
NurtureHandler._legacyExecute = function (params) {
  var duration = params.duration || 30;
  var actions = params.actions || [
    { type: "browse_feed", weight: 70 },
    { type: "like", weight: 20 },
    { type: "follow", weight: 10 },
  ];

  logger.info(TAG, "开始养号(旧版) " + duration + " 分钟");

  if (!this.ensureAppActive()) {
    return { success: false, error: "Failed to open Douyin" };
  }

  var startTime = Date.now();
  var endTime = startTime + duration * 60 * 1000;
  var stats = { videos_watched: 0, likes: 0, follows: 0, errors: 0 };

  while (Date.now() < endTime) {
    this._ensureOnFeed();
    var action = this._weightedRandom(actions);
    try {
      switch (action.type) {
        case "browse_feed":
          this._browseFeed();
          break;
        case "like":
          this._likeCurrentVideo();
          break;
        case "follow":
          this._followCurrentUser();
          break;
        default:
          this._browseFeed();
      }
    } catch (e) {
      logger.error(TAG, "养号操作 '" + action.type + "' 出错: " + e.message);
      stats.errors++;
    }
    antiDetect.humanSwipeUp();
    stats.videos_watched++;
  }

  logger.info(TAG, "养号完成. 统计: " + JSON.stringify(stats));
  return { success: true, result: stats };
};

NurtureHandler._weightedRandom = function (actions) {
  var totalWeight = actions.reduce(function (sum, a) { return sum + a.weight; }, 0);
  var random = Math.random() * totalWeight;
  var cumulative = 0;
  for (var i = 0; i < actions.length; i++) {
    cumulative += actions[i].weight;
    if (random < cumulative) return actions[i];
  }
  return actions[0];
};

module.exports = NurtureHandler;
